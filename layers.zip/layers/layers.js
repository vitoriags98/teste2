ol.proj.proj4.register(proj4);
ol.proj.get("").setExtent([-1591738.941317, 6112520.743209, 4358894.360971, 9451553.457919]);
var wms_layers = [];


        var lyr_GoogleSatellite_0 = new ol.layer.Tile({
            'title': 'Google Satellite',
            //'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'
            })
        });
var format_BR_UF_2022_1 = new ol.format.GeoJSON();
var features_BR_UF_2022_1 = format_BR_UF_2022_1.readFeatures(json_BR_UF_2022_1, 
            {dataProjection: 'EPSG:4326', featureProjection: ''});
var jsonSource_BR_UF_2022_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_BR_UF_2022_1.addFeatures(features_BR_UF_2022_1);
var lyr_BR_UF_2022_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_BR_UF_2022_1, 
                style: style_BR_UF_2022_1,
                popuplayertitle: "BR_UF_2022",
                interactive: true,
                title: '<img src="styles/legend/BR_UF_2022_1.png" /> BR_UF_2022'
            });
var format_BR_Municipios_2022_2 = new ol.format.GeoJSON();
var features_BR_Municipios_2022_2 = format_BR_Municipios_2022_2.readFeatures(json_BR_Municipios_2022_2, 
            {dataProjection: 'EPSG:4326', featureProjection: ''});
var jsonSource_BR_Municipios_2022_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_BR_Municipios_2022_2.addFeatures(features_BR_Municipios_2022_2);
var lyr_BR_Municipios_2022_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_BR_Municipios_2022_2, 
                style: style_BR_Municipios_2022_2,
                popuplayertitle: "BR_Municipios_2022",
                interactive: true,
                title: '<img src="styles/legend/BR_Municipios_2022_2.png" /> BR_Municipios_2022'
            });

lyr_GoogleSatellite_0.setVisible(true);lyr_BR_UF_2022_1.setVisible(true);lyr_BR_Municipios_2022_2.setVisible(true);
var layersList = [lyr_GoogleSatellite_0,lyr_BR_UF_2022_1,lyr_BR_Municipios_2022_2];
lyr_BR_UF_2022_1.set('fieldAliases', {'CD_UF': 'CD_UF', 'NM_UF': 'NM_UF', 'SIGLA_UF': 'SIGLA_UF', 'NM_REGIAO': 'NM_REGIAO', 'AREA_KM2': 'AREA_KM2', });
lyr_BR_Municipios_2022_2.set('fieldAliases', {'CD_MUN': 'CD_MUN', 'NM_MUN': 'NM_MUN', 'SIGLA_UF': 'SIGLA_UF', 'AREA_KM2': 'AREA_KM2', });
lyr_BR_UF_2022_1.set('fieldImages', {'CD_UF': 'TextEdit', 'NM_UF': 'TextEdit', 'SIGLA_UF': 'TextEdit', 'NM_REGIAO': 'TextEdit', 'AREA_KM2': 'TextEdit', });
lyr_BR_Municipios_2022_2.set('fieldImages', {'CD_MUN': 'TextEdit', 'NM_MUN': 'TextEdit', 'SIGLA_UF': 'TextEdit', 'AREA_KM2': 'TextEdit', });
lyr_BR_UF_2022_1.set('fieldLabels', {'CD_UF': 'inline label - always visible', 'NM_UF': 'inline label - always visible', 'SIGLA_UF': 'inline label - always visible', 'NM_REGIAO': 'inline label - always visible', 'AREA_KM2': 'inline label - always visible', });
lyr_BR_Municipios_2022_2.set('fieldLabels', {'CD_MUN': 'inline label - always visible', 'NM_MUN': 'inline label - always visible', 'SIGLA_UF': 'inline label - always visible', 'AREA_KM2': 'inline label - always visible', });
lyr_BR_Municipios_2022_2.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});